<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


// 連線到資料庫
$host = 'localhost';
$dbname = '0425hw_registration';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    exit("資料庫連線失敗: " . $conn->connect_error);
}

// 收資料
$name = $_POST['name'];
$email = $_POST['email'];
$photo = $_FILES['photo'];

// 上傳照片
$uploadDir = 'uploads/';
$photoName = uniqid() . '_' . basename($photo['name']);
$uploadPath = $uploadDir . $photoName;

if (!move_uploaded_file($photo['tmp_name'], $uploadPath)) {
    sendMail($email, $name, false, null, "照片上傳失敗，請重新註冊：<a href='http://localhost/register.html'>註冊頁面</a>");
    exit("照片上傳失敗");
}

// 寫入資料庫
$stmt = $conn->prepare("INSERT INTO user (name, email, photo) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $photoName);

if ($stmt->execute()) {
    sendMail($email, $name, true, $uploadPath);
    echo "註冊成功，已寄信通知";
} else {
    sendMail($email, $name, false, null, "資料庫寫入失敗，請重新註冊：<a href='http://localhost/register.html'>註冊頁面</a>");
    echo "資料庫寫入失敗";
}

$stmt->close();
$conn->close();

// 寄信函式
function sendMail($to, $name, $success, $photoPath = null, $failMsg = '')
{
    $mail = new PHPMailer(true);
    try {
        // 設定
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'amy05290207@gmail.com';
        $mail->Password = 'kdvk zfzb okya ugat';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        $mail->setFrom('amy05290207@gmail.com', 'Meng');
        $mail->addAddress($to, $name);

        if ($success) {
            $mail->Subject = '註冊成功通知';
            $mail->Body = "您好". $name."，您的註冊已成功！<br>感謝您的使用。";
            $mail->isHTML(true);
            $mail->CharSet = 'UTF-8';            // 設定郵件的字元編碼為 UTF-8
            $mail->Encoding = 'base64';          // 設定內容編碼方式（避免中文亂碼）

            if ($photoPath) {
                $mail->addAttachment($photoPath);
            }
        } else {
            $mail->Subject = '註冊失敗通知';
            $mail->Body = "您好 {$name}，註冊失敗。<br>{$failMsg}";
            $mail->isHTML(true);
        }

        $mail->send();
    } catch (Exception $e) {
        echo "寄信錯誤: {$mail->ErrorInfo}";
    }
}
?>
