<form action="register.php" method="post" enctype="multipart/form-data">

Name:<input type="text" name="name"><br>
Mail:<input type="email" name="email"><br>
Photo:
<input type="file" name="photo" accept="image/*"><br>
<input type="submit" value="註冊">

</form>